package tp_ejercicio01;

import java.util.ArrayList;
import java.util.List;

public class Agenda {

    private String propietario;
    private List<Reunion> reuniones;

    public Agenda(String propietario){
        this.propietario = propietario;
        this.reuniones = new ArrayList<>();
    }

    public void agregarReunion(Reunion r){
        this.reuniones.add(r);
    }

    public String getPropietario() {
        return propietario;
    }

    public List<Reunion> getReuniones(){
        return reuniones;
    }
}
