package tp_ejercicio01;

import java.util.ArrayList;
import java.util.List;

public class Reunion {

    private String lugar;
    private String tema;
    private int duracionReunion;
    private List<Participante> participantes;

    public Reunion(){}

    public Reunion(String lugar, String tema, int duracionReunion){
        this.lugar = lugar;
        this.tema = tema;
        this.duracionReunion = duracionReunion;
        this.participantes = new ArrayList<>();
    }

    public void agregarParticipante(Participante p){
        this.participantes.add(p);
    }

    public String getLugar(){
        return lugar;
    }

    public String getTema(){
        return tema;
    }

    public int getDuracionReunion(){
        return duracionReunion;
    }

    public List<Participante> getParticipantes(){
        return participantes;
    }
}
