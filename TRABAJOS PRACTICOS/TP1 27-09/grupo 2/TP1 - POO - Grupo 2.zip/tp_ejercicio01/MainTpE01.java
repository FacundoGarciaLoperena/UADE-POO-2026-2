package tp_ejercicio01;

public class MainTpE01 {
    public static void main(String[] args){
        //crear una agenda
        Agenda agenda1 = new Agenda("Cosme Fulanito");

        //crear una reu
        Reunion reu1 = new Reunion("Sala 202", "requerimientos del sistema", 40);

        //crear participantes
        Participante p1 = new Participante("charly");
        Participante p2 = new Participante("Pipo");

        //agregar participantes a la reunion
        reu1.agregarParticipante(p1);
        reu1.agregarParticipante(p2);

        //agregar reu a la agenda
        agenda1.agregarReunion(reu1);

        // print para mostrar la reu
        System.out.println("Agenda de: " + agenda1.getPropietario());
        for (Reunion r : agenda1.getReuniones()) {
            System.out.println("- Tema: " + r.getTema());
            System.out.println("  Lugar: " + r.getLugar());
            System.out.println("  Duración: " + r.getDuracionReunion() + " min");
            System.out.println("  Participantes:");
            for (Participante p : r.getParticipantes()) {
                System.out.println("    * " + p.getNombre());
            }
        }

    }
}
