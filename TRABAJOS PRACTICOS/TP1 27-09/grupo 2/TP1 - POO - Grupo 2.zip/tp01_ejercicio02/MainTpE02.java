package tp01_ejercicio02;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MainTpE02 {

    public static void main(String[] args) {
        // 1. Catálogo de vuelos disponibles
        List<Vuelo> vuelosDisponibles = new ArrayList<>();
        vuelosDisponibles.add(new Vuelo("Madrid", LocalDate.of(2026, 10, 15), 5));
        vuelosDisponibles.add(new Vuelo("Madrid", LocalDate.of(2026, 10, 20), 0)); // Lleno

        // 2. El usuario especifica sus preferencias
        PreferenciaViaje preferencias = new PreferenciaViaje(
                "Madrid",
                LocalDate.of(2026, 10, 10),
                LocalDate.of(2026, 10, 18),
                "Turista",
                "No Fumador"
        );

        // 3. El sistema busca vuelos que coincidan
        Vuelo vueloElegido = null;
        for (Vuelo v : vuelosDisponibles) {
            if (v.coincideConPreferencias(preferencias)) {
                vueloElegido = v;
                break; // Se ofrece y acepta el primero que coincide
            }
        }

        // 4. Si hay vuelo y el usuario confirma, se piden sus datos y se emite el pasaje
        if (vueloElegido != null) {
            Cliente cliente = new Cliente("Cosme fulanito", "cosme@email.com");
            vueloElegido.reservarAsiento();

            Pasaje pasaje = new Pasaje(1001, cliente, vueloElegido);

            System.out.println("Pasaje emitido con éxito.");
            System.out.println("Pasajero: " + pasaje.getCliente().getNombre());
            System.out.println("Destino: " + pasaje.getVuelo().getDestino() + " - Fecha: " + pasaje.getVuelo().getFecha());
        } else {
            System.out.println("No se encontraron vuelos para sus preferencias. Lo invitamos a pasar en otro momento.");
        }
    }
}
