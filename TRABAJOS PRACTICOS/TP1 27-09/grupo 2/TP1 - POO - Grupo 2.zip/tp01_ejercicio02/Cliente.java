package tp01_ejercicio02;

public class Cliente {

    private String nombre;
    private String datosContacto;

    public Cliente(String nombre, String datosContacto) {
        this.nombre = nombre;
        this.datosContacto = datosContacto;
    }

    public String getNombre() { return nombre; }
    public String getDatosContacto() { return datosContacto; }
}
