package tp01_ejercicio02;

import java.time.LocalDate;

public class Vuelo {

    private String destino;
    private LocalDate fecha;
    private int asientosDisponibles;

    public Vuelo(String destino, LocalDate fecha, int asientosDisponibles) {
        this.destino = destino;
        this.fecha = fecha;
        this.asientosDisponibles = asientosDisponibles;
    }

    public boolean coincideConPreferencias(PreferenciaViaje pref) {
        boolean destinoCoincide = this.destino.equalsIgnoreCase(pref.getCiudadDestino());
        boolean fechaValida = !this.fecha.isBefore(pref.getFechaTemprana()) && !this.fecha.isAfter(pref.getFechaTardia());
        boolean hayLugar = this.asientosDisponibles > 0;

        return destinoCoincide && fechaValida && hayLugar;
    }

    public void reservarAsiento() {
        if (asientosDisponibles > 0) asientosDisponibles--;
    }

    public String getDestino() { return destino; }
    public LocalDate getFecha() { return fecha; }
}
