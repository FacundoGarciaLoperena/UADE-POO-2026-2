package tp01_ejercicio02;

import java.time.LocalDate;

public class PreferenciaViaje {

    private String ciudadDestino;
    private LocalDate fechaTemprana;
    private LocalDate fechaTardia;
    private String claseViaje;
    private String seccion;

    public PreferenciaViaje(String ciudadDestino, LocalDate fechaTemprana, LocalDate fechaTardia, String claseViaje, String seccion) {
        this.ciudadDestino = ciudadDestino;
        this.fechaTemprana = fechaTemprana;
        this.fechaTardia = fechaTardia;
        this.claseViaje = claseViaje;
        this.seccion = seccion;
    }

    public String getCiudadDestino() { return ciudadDestino; }
    public LocalDate getFechaTemprana() { return fechaTemprana; }
    public LocalDate getFechaTardia() { return fechaTardia; }
    public String getClaseViaje() { return claseViaje; }
    public String getSeccion() { return seccion; }
}
