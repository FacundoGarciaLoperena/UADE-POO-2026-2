package tp01_ejercicio02;

public class Pasaje {

    private int numeroPasaje;
    private Cliente cliente;
    private Vuelo vuelo;

    public Pasaje(int numeroPasaje, Cliente cliente, Vuelo vuelo) {
        this.numeroPasaje = numeroPasaje;
        this.cliente = cliente;
        this.vuelo = vuelo;
    }

    public int getNumeroPasaje() { return numeroPasaje; }
    public Cliente getCliente() { return cliente; }
    public Vuelo getVuelo() { return vuelo; }
}
